# USTAAD Development — Agent Reasoning Traces

This document records the step-by-step reasoning traces produced by Google Antigravity during the development of the USTAAD app. Each trace shows how the orchestration agent analyzed a task, broke it into subtasks, selected tools, and executed actions.

---

## Trace 1: Project Architecture Design

**Trigger**: "Build an Agentic AI app for Pakistan's informal service economy"

**Agent Reasoning**:
```
Step 1: ANALYZE — Parse the problem domain
  → Pakistan informal economy = unregistered workers, no digital presence
  → Need: discovery, trust (verification), booking, follow-up
  → Three roles identified: Customer, Worker, Admin

Step 2: PLAN — Select technology stack
  → Cross-platform needed (web for demo, Android for real users)
  → Flutter selected: single codebase, excellent web + mobile support
  → Firebase Auth: fastest auth implementation for hackathon
  → Firestore: real-time NoSQL for user data
  → JSONBin (Vercel proxy): lightweight cloud storage, no backend needed
  → Decision: Hybrid database = Firestore for auth-linked data + JSONBin for operational data

Step 3: DESIGN — Architecture diagram
  → Customer Client → Firebase Auth → Firestore (users) + JSONBin (bookings)
  → Worker Client → Firebase Auth → JSONBin (technicians)
  → Admin Portal → JSONBin (technicians, complaints)
  → Google Maps API → Location services for all clients

Step 4: EXECUTE — Scaffold project
  → flutter create ustaad
  → Configure pubspec.yaml with 12 dependencies
  → Set up folder structure: screens/, data/, widgets/, theme/, routing/
```

---

## Trace 2: AI Processing Pipeline Implementation

**Trigger**: "Create the agentic AI orchestration screen"

**Agent Reasoning**:
```
Step 1: ANALYZE — What does "agentic" mean for this context?
  → Multi-step reasoning visible to the user
  → Planning → Decision → Action → Follow-up pipeline
  → Each step must show extracted entities from user input

Step 2: PLAN — Design the 7-step reasoning trace
  1. Parse request intent (extract service type)
  2. Analyze service category (map to internal categories)
  3. Location extraction (isolate city with strict geofencing)
  4. Schedule parsing (date + time extraction)
  5. Work specification cross-reference (match problem to skills)
  6. Registry query (filter technicians by city + category + status)
  7. AI ranking optimization (sort by rating, distance, performance)

Step 3: DESIGN — UI/UX decisions
  → Animated step indicators with timed progression (650ms per step)
  → RobotoMono timestamps for "terminal" aesthetic
  → Circular progress indicator with step count
  → Pipeline phase bar: Planning → Decision → Action → Follow-up
  → Request summary card showing extracted entities

Step 4: EXECUTE — Build ai_processing_screen.dart
  → Timer.periodic for step advancement
  → Dynamic subtitles populated from bookingDetails map
  → _getCityName() helper for city extraction
  → Auto-navigation to provider_discovery after completion

Step 5: VERIFY — Test with multiple inputs
  → "AC repair in G-13 Islamabad" → correctly extracts HVAC + Islamabad
  → "Plumber needed in Lahore DHA" → correctly isolates Lahore
  → "Electrician tomorrow morning" → correctly parses schedule
```

---

## Trace 3: Worker Login Bug Resolution

**Trigger**: "Worker whose application has been approved by admin still gets 'Under Review' error"

**Agent Reasoning**:
```
Step 1: DIAGNOSE — Trace the data flow
  → Worker registers → data saved WHERE?
  → Found: DocumentDatabase.addTechnician() saves to JSONBin cloud
  → Admin approves → DocumentDatabase.updateTechnician() updates JSONBin
  → Worker login → tech_login_screen.dart reads... WHERE?

Step 2: IDENTIFY ROOT CAUSE
  → CRITICAL FINDING: tech_login_screen.dart was reading from:
    FirebaseFirestore.instance.collection('workers').doc(user.uid)
  → But worker approval status lives in JSONBin, NOT Firestore!
  → Firestore 'workers' collection may have initial registration data
    but admin NEVER updates Firestore — admin updates JSONBin only
  → Result: Firestore doc either doesn't exist or has stale 'pending' status

Step 3: PLAN FIX
  → Replace Firestore read with DocumentDatabase.syncFromCloud()
  → Find technician by email in onboardedTechnicians list
  → Read status field with case-insensitive comparison
  → Handle all cases: approved, pending, rejected, not found

Step 4: EXECUTE FIX
  → Removed: FirebaseFirestore.instance.collection('workers')...
  → Added: await DocumentDatabase.syncFromCloud()
  → Added: DocumentDatabase.onboardedTechnicians.firstWhere(email match)
  → Added: status.toLowerCase().trim() == 'approved' check
  → Added: debugPrint for diagnostic logging
  → Removed unused cloud_firestore import

Step 5: VERIFY
  → flutter build web --release (success, 317.8s)
  → git push origin main (deployed to Vercel)
  → Flow: Register worker → Admin approves → Worker login → SUCCESS
```

---

## Trace 4: Provider Discovery with City Filtering

**Trigger**: "Show only relevant technicians for the user's city"

**Agent Reasoning**:
```
Step 1: ANALYZE — Current provider list is unfiltered
  → Shows ALL technicians regardless of city
  → A Lahore customer sees Islamabad workers (wrong!)

Step 2: PLAN — Strict geofencing strategy
  → Extract target city from booking request location
  → Filter DocumentDatabase.onboardedTechnicians by:
    a) city matches target city (case-insensitive)
    b) status == 'approved'
    c) category matches requested service
  → Sort remaining by rating descending

Step 3: EXECUTE — Update provider_discovery_screen.dart
  → Added _getCityName() city extraction helper
  → Added filtering pipeline with .where() chains
  → Added sorting by rating field
  → Added empty-state UI when no matches found

Step 4: VERIFY — Test scenarios
  → Islamabad request → only Islamabad techs shown ✓
  → Lahore request → only Lahore techs shown ✓
  → Category mismatch → empty state shown ✓
```

---

## Trace 5: Real-Time Cloud Sync Architecture

**Trigger**: "Data must persist across devices and sessions"

**Agent Reasoning**:
```
Step 1: ANALYZE — Requirements
  → Web and Android must see same data
  → Changes on one device must appear on another
  → Must work offline (graceful degradation)

Step 2: DESIGN — Sync pattern
  → Local-first: PlatformStorage (SharedPreferences) as cache
  → Cloud source: JSONBin REST API (GET/PUT)
  → Sync-on-read: syncFromCloud() on every screen init
  → Sync-on-write: syncToCloud() after every mutation
  → Conflict resolution: cloud wins (last-write-wins)

Step 3: EXECUTE — Implement across 3 repositories
  → BookingsRepository: bookings + complaints (2 bins)
  → DocumentDatabase: technicians (1 bin)
  → UserDatabase: registered users (1 bin)
  → Total: 4 JSONBin endpoints, each with GET/PUT sync

Step 4: VERIFY
  → Book on web → appears on Android after app restart ✓
  → Admin approves on web → worker can login on Android ✓
```

---

## Trace 6: Google Maps Cross-Platform Integration

**Trigger**: "Integrate maps for location selection"

**Agent Reasoning**:
```
Step 1: ANALYZE — Platform differences
  → Android: google_maps_flutter works natively
  → Web: google_maps_flutter has limited web support
  → Need different implementations per platform

Step 2: PLAN — Conditional rendering
  → google_map_mobile.dart: Uses GoogleMap widget + markers + camera
  → google_map_web.dart: Uses dart:html + JS interop to inject google.maps.Map
  → google_places_autocomplete.dart: Shared across platforms

Step 3: EXECUTE
  → Android: Standard GoogleMap with initial camera position
  → Web: Create div element, register with ViewFactory, call JS initMap()
  → Autocomplete: Autocomplete<String> widget with GoogleMapsService calls
  → API key embedded: AIzaSyCfyfXA-jSL2Gwc9p3lML2V6z-AwKW0m0w

Step 4: VERIFY
  → Maps render on both web and Android ✓
  → Autocomplete shows suggestions ✓
  → Location selection updates booking request ✓
```

---

## Trace 7: Booking Lifecycle Management

**Trigger**: "Build complete booking flow from confirmation to follow-up"

**Agent Reasoning**:
```
Step 1: ANALYZE — Booking states needed
  → Confirmed (new booking)
  → Service In Progress (worker arrived)
  → Completed (work done, ready for review)
  → Cancelled (with reason and notes)

Step 2: PLAN — Features per state
  → Confirmed: Edit details, Cancel booking, Track provider
  → In Progress: Live status, Contact provider
  → Completed: View receipt, Rate & Review, Raise complaint
  → Cancelled: View cancellation reason

Step 3: EXECUTE — Build my_bookings_screen.dart
  → Tab-based UI: Active / Completed / Cancelled
  → Each booking card shows status badge with color coding
  → Tap actions route to appropriate detail/action screens
  → BookingsRepository handles all CRUD with cloud sync

Step 4: EXECUTE — Build follow_up_screen.dart
  → Rating widget (1-5 stars with tap interaction)
  → Review text field
  → Complaint form with category dropdown + photo evidence
  → Submit → BookingsRepository.rateBooking() or addComplaint()
```

---

## Trace 8: README Documentation Generation

**Trigger**: "Create complete professional README documentation"

**Agent Reasoning**:
```
Step 1: ANALYZE — Full codebase scan
  → Searched for: agent, gemini, vertex, ai, antigravity
  → Mapped all files in lib/screens/, lib/data/, lib/widgets/
  → Read pubspec.yaml for complete dependency list
  → Traced all API endpoints and cloud URLs
  → Identified all Firebase collections used

Step 2: PLAN — README sections
  → 14 sections covering architecture, agents, APIs, workflow,
    features, tech stack, setup, deployment, credentials, mock vs real

Step 3: EXECUTE — Write README.md
  → 210 lines of professional documentation
  → Architecture diagram in ASCII art
  → API table with real vs simulated distinction
  → Demo credentials for all 3 roles

Step 4: EXECUTE — Generate PDF
  → npm install markdown-pdf
  → npx markdown-pdf README.md → README.pdf (65KB)

Step 5: DEPLOY
  → git push → both files live at github.com/Shaheerali66/Ustaad
```
