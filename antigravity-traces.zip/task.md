# Firebase Integration Tasks

- `[x]` Add Firebase dependencies (`firebase_core`, `firebase_auth`, `cloud_firestore`).
- `[x]` Create `firebase_options.dart` with provided config.
- `[x]` Update `web/index.html` with Firebase scripts.
- `[x]` Update `main.dart` to initialize Firebase and set Auth Persistence to LOCAL.
- `[x]` Update Customer Login to use Firebase Auth.
- `[x]` Update Customer Signup to use Firebase Auth and save to Firestore `users` collection.
- `[x]` Update Worker Login to use Firebase Auth.
- `[x]` Update Worker Registration to use Firebase Auth and save to Firestore `workers` collection.
- `[x]` Create and execute script to programmatically create the two requested demo accounts.
- `[x]` Test login programmatically with demo accounts.
- `[x]` Commit and push changes to GitHub.
