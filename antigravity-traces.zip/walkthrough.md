# USTAAD App — Complete Development Walkthrough

## Overview
This walkthrough documents every major feature implemented in USTAAD, the decisions made, and the exact steps taken during development.

---

## 1. Project Initialization

**Action taken**: Created Flutter project `ustaad` with package name `com.ustaad.app`.

**Key files created**:
- `pubspec.yaml` with dependencies: `flutter`, `go_router`, `google_fonts`, `firebase_core`, `firebase_auth`, `cloud_firestore`, `google_maps_flutter`, `http`, `shared_preferences`, `js`, `universal_html`
- `lib/main.dart` with Firebase initialization and router setup
- `lib/theme/app_colors.dart` defining the complete color system

**Decision**: Used Material 3 design tokens with a custom teal/blue color palette for a professional, premium look.

---

## 2. Authentication System

### Customer Auth (Firebase)
**Files**: `lib/screens/customer/login_screen.dart`, `lib/screens/customer/signup_screen.dart`

**Flow implemented**:
1. Customer fills email/password on signup
2. `FirebaseAuth.instance.createUserWithEmailAndPassword()` creates Firebase Auth account
3. `FirebaseFirestore.instance.collection('users').doc(uid).set(userData)` saves profile
4. On login: `signInWithEmailAndPassword()` → fetch Firestore doc → load into `UserDatabase._currentUser`
5. Route to `/customer/home`

**Bug fixed**: Added `forceLogin` flag and data sanitization in `UserDatabase` to prevent login loops caused by stale local cache data.

### Worker Auth (JSONBin)
**File**: `lib/screens/technician/tech_login_screen.dart`

**Critical bug identified and fixed**:
- **Original buggy code**: Read worker status from Firestore `workers` collection → worker always got "Under Review" error even after admin approval.
- **Root cause**: Worker data lives in `DocumentDatabase` (JSONBin), NOT Firestore. The Firestore `workers` collection doesn't contain approval status.
- **Fix applied**: After Firebase Auth succeeds, call `DocumentDatabase.syncFromCloud()` then find worker by email in `onboardedTechnicians` list, read `.status` field with case-insensitive comparison.

**Status logic**:
```dart
final status = tech['status']?.toString().toLowerCase().trim() ?? 'pending';
if (status == 'approved') → navigate to Worker Dashboard
if (status == 'pending') → show "Under Review" error
if (status == 'rejected') → show "Application Rejected" error
```

### Admin Auth
**File**: `lib/screens/admin/admin_login_screen.dart`

Simple hardcoded credential check — no Firebase required for admin role. Routes to `/admin/dashboard`.

---

## 3. Agentic AI Processing Screen

**File**: `lib/screens/customer/ai_processing_screen.dart`

**What it does**: Simulates the Google Antigravity orchestration engine processing a customer's service request through a 7-step pipeline.

**Implementation**:
- `Timer.periodic(Duration(milliseconds: 650))` advances through steps
- Each step shows a title, subtitle with extracted entities (service, city, date, time)
- Pipeline progress bar: Planning → Decision → Action → Follow-up
- `_getCityName()` extracts city from location string (Lahore, Karachi, Hyderabad, Islamabad)
- After all 7 steps, navigates to `provider_discovery_screen.dart` with booking data passed via `extra`

**Design decision**: Used animated step indicators with timestamps in `RobotoMono` font to give the feel of a real AI terminal output.

---

## 4. Provider Discovery with City Filtering

**File**: `lib/screens/customer/provider_discovery_screen.dart`

**How matching works**:
1. Reads `bookingDetails` map passed from AI processing screen
2. Extracts target city from location string
3. Filters `DocumentDatabase.onboardedTechnicians` to only show:
   - Workers whose `city` matches the target city
   - Workers with `status == 'approved'`
   - Workers whose `category` matches the requested service
4. Displays ranked list sorted by rating (highest first)

**Design decision**: Strict city-level geofencing — a Lahore technician NEVER appears in an Islamabad search.

---

## 5. Booking System

### Repository: `lib/data/bookings_repository.dart`

**Data model** (`BookingData`):
- `id`, `title`, `provider`, `date`, `time`, `status`, `statusColor`, `action`, `icon`
- Rich metadata: `providerName`, `providerPhoto`, `providerPhone`, `location`, `amount`, `baseRate`, `hoursWorked`, `extraCharges`, `paymentMethod`, `duration`, `workDetails`
- Optional: `rating`, `review`, `cancellationReason`, `cancellationNotes`

**Cloud sync**:
- Bookings bin: `https://jsonbin-zeta.vercel.app/api/bins/L5f2Y_PZP-`
- Complaints bin: `https://jsonbin-zeta.vercel.app/api/bins/beyrzqQzfw`
- Pattern: fetch from cloud → merge with local → push mutations back to cloud

**Booking statuses**:
- `Confirmed` (blue/primary) — booked but not started
- `Service In Progress` (blue) — worker has arrived
- `Completed` (green) — work done
- `Cancelled` (grey) — cancelled with reason

**Booking ID format**: `#KAI-YYYYMMDD-NNN` generated from epoch milliseconds

---

## 6. Admin Dashboard

**File**: `lib/screens/admin/admin_dashboard_screen.dart`

**Features**:
1. **Worker Verification Tab**: Lists all workers with `status == 'pending'`. Admin taps Approve/Reject → calls `DocumentDatabase.updateTechnician()` → status written to JSONBin cloud.
2. **Complaints Tab**: Lists all complaints from `BookingsRepository.complaints`. Admin marks as Resolved with notes → calls `BookingsRepository.updateComplaintStatus()`.
3. **Overview Tab**: Displays platform metrics (total workers, active bookings, complaints).

**Critical design**: Admin approval writes lowercase `'approved'` / `'rejected'` to JSONBin, matching the case-insensitive check in worker login.

---

## 7. Real-Time Sync Architecture

**Pattern used across all repositories**:
1. On `init()`: Load from `PlatformStorage` (local cache) first (instant)
2. Then `syncFromCloud()`: Fetch fresh data from JSONBin, overwrite local cache
3. On every mutation: update local first, then `syncToCloud()` pushes to JSONBin

**Cross-platform storage**: `lib/data/platform_storage.dart` wraps `SharedPreferences` for both Web and Android with identical API.

---

## 8. Google Maps Integration

### Android: `lib/widgets/google_map_mobile.dart`
- Uses `google_maps_flutter` package's `GoogleMap` widget
- Fetches static map tiles for thumbnails using Maps Static API
- Supports marker placement, camera movement

### Web: `lib/widgets/google_map_web.dart`
- Uses `dart:html` via `universal_html` package
- Creates a `<div>` element with unique ID, injects `google.maps.Map` via JS interop
- Handles map initialization with `js.context.callMethod('initMap', [containerId, lat, lng])`

### Places Autocomplete: `lib/widgets/google_places_autocomplete.dart`
- Custom `Autocomplete<String>` widget
- Calls `GoogleMapsService.getPlaceSuggestions(query)` which hits Places API
- Displays dropdown with up to 5 suggestions

---

## 9. Worker Onboarding Flow

**Files**: `tech_onboarding_screen.dart`, `tech_documents_screen.dart`

**Steps**:
1. Personal info form (name, phone, city, category)
2. CNIC upload (front + back photo)
3. Professional document upload
4. Submit → `DocumentDatabase.addTechnician()` with `status: 'pending'`
5. Also writes to Firestore `workers` collection (for auth linkage)
6. Worker sees "Under Review" screen until admin approves

---

## 10. Deployment Pipeline

### Web Deployment (Vercel)
1. `flutter build web --release` → `build/web/`
2. `git push origin main`
3. Vercel detects push → auto-deploys `build/web/` as static site
4. No server-side rendering — pure static Flutter web PWA

### Android Build
1. `flutter build apk --release` → `build/app/outputs/apk/release/app-release.apk`
2. Distributed directly for hackathon demo

---

## 11. Key Bugs Fixed During Development

| Bug | Root Cause | Fix Applied |
|-----|-----------|-------------|
| Worker always sees "Under Review" after admin approval | Login read from Firestore (wrong store) | Fixed to read from DocumentDatabase (JSONBin) |
| Customer login redirect loop | Stale local cache with wrong role | Added `forceLogin` flag and cache sanitization |
| Google Maps not loading on web | JS interop API mismatch | Used `universal_html` + proper container ID pattern |
| Provider list showing wrong city technicians | No city filter applied | Strict city extraction + lowercase comparison |
| Booking ID collision | Simple counter reset on app restart | Used epoch milliseconds modulo for uniqueness |
