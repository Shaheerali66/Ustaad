# USTAAD Development — Architectural Decisions Log

This document records the major design, architectural, and logical decisions made during the development of USTAAD.

---

## Decision 1: Hybrid Storage System (Firestore + JSON Cloud Bins)
* **Context**: The app needs real-time synchronization between clients (Customer, Worker, Admin) without deploying a custom Node.js/Python backend server.
* **Options**:
  1. *Firestore only*: Highly secure, but requires complicated complex Firestore Rules and client-side setup for rapid prototyping.
  2. *Custom SQL Backend*: Slowest to build, deployment overhead.
  3. *Hybrid (Firestore + JSON Bins via Vercel)*: Use Firebase Auth for authentication, Firestore for basic user metadata, and lightweight cloud JSON bins (`jsonbin-zeta.vercel.app`) for real-time dynamic records (bookings, technicians, complaints).
* **Selection**: Option 3.
* **Rationale**: This allows extremely fast REST-based synchronizations, works natively on both web and mobile with simple HTTP GET/PUT, keeps auth secure via Firebase, and avoids the complexity of writing backend server routes.

---

## Decision 2: Local-First Synchronization Architecture
* **Context**: Network latency in Pakistan's informal economy is highly variable; the app must load instantly and work gracefully under poor connectivity.
* **Options**:
  1. *Direct Cloud Reads*: App calls APIs on every rebuild. (Slow and error-prone under poor connection).
  2. *Local-First Cache Sync*: Hydrate UI instantly from local `PlatformStorage` (SharedPreferences wrapper). Fetch updates in the background via async REST queries and overwrite cache. Write local-first, then sync to cloud.
* **Selection**: Option 2.
* **Rationale**: Guarantees zero latency on screen transitions. If a cloud write fails, the client is still functional, and sync retries on the next app load.

---

## Decision 3: Cross-Platform Map Render Integration
* **Context**: Rendering Google Maps on both Flutter Web and Android requires two vastly different rendering targets.
* **Options**:
  1. *google_maps_flutter package*: Works perfectly on mobile, but web requires loading external scripts in `index.html` which slow down page loads and cause runtime interop crashes.
  2. *Platform-Conditional Implementations*: Write an abstract widget, using raw Android Native view on mobile and `universal_html` + raw JavaScript mapping interop on Web.
* **Selection**: Option 2.
* **Rationale**: Using the HTML mapping interop on Web prevents loading large package overheads on initial loading, ensuring the web app loads in under 2 seconds.

---

## Decision 4: Case-Insensitive Status Parsing
* **Context**: Admin marks workers as `'Approved'` (title case) in the dashboard UI for readability. However, during login checks, spelling or casing mismatches can prevent worker access.
* **Selection**: Enforced a strict lowercase normalization filter (`status.toLowerCase().trim()`) during the auth loop.
* **Rationale**: Eliminates human-error discrepancies in status strings, ensuring that `'approved'`, `'Approved'`, or `'APPROVED'` are treated identically.
