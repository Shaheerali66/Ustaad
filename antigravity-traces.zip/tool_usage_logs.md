# USTAAD Development — Tool and API Usage Logs

This document lists the main development tools, commands, and cloud APIs executed during the building of the USTAAD application.

---

## 1. IDE & Terminal Tool Executions

### Flutter Build Commands
* **Web Build**:
  ```bash
  flutter build web --release
  ```
  *Purpose*: Compiles the Flutter app to production-ready JS and HTML assets in the `build/web` directory for Vercel deployment. Optimized with tree-shaking for asset sizes.
  *Frequency*: Executed at major release points.

* **Android Build**:
  ```bash
  flutter build apk --release
  ```
  *Purpose*: Compiles the codebase into an installable release APK.

* **Dependency Hydration**:
  ```bash
  flutter pub get
  ```
  *Purpose*: Fetches all packages listed in `pubspec.yaml` (Firebase, Routing, Storage).

### Git & Deployment Commands
* **Git Version Control**:
  ```bash
  git add .
  git commit -m "Fix worker login status check bug"
  git push origin main
  ```
  *Purpose*: Saves code modifications and pushes to GitHub, automatically triggering Vercel web hosting deployments.

### Local Conversion Tools
* **PDF Documentation Engine**:
  ```bash
  npx -y markdown-pdf README.md
  ```
  *Purpose*: Generates highly structured, printable documentation (README.pdf) directly from the project root.

---

## 2. Real-Time Cloud Integration Logs

### Custom REST JSON Bins
The system relies on high-fidelity operational APIs hosted on Vercel:
* **Bookings Endpoint**: `https://jsonbin-zeta.vercel.app/api/bins/L5f2Y_PZP-`
  *HTTP Method*: `GET` / `PUT`
  *Structure*: JSON array of bookings containing rich metadata (pricing, provider info, coordinates).
* **Technician Registry Endpoint**: `https://jsonbin-zeta.vercel.app/api/bins/d5f2Y_PZP-` (Example dynamic bin ID)
  *HTTP Method*: `GET` / `PUT`
  *Structure*: Holds worker names, verification flags, uploaded document refs, and cities.
* **Customer Registry Endpoint**: `https://jsonbin-zeta.vercel.app/api/bins/VRHuwcv2Jv`
* **Complaints Registry Endpoint**: `https://jsonbin-zeta.vercel.app/api/bins/beyrzqQzfw`

### Firebase Integration APIs
* **Firebase Authentication REST Endpoint**: `identitytoolkit.googleapis.com`
  *Purpose*: Handles secure email/password credential storage, token generation, and secure session management.
* **Cloud Firestore Database**: `firestore.googleapis.com`
  *Purpose*: Persists initial profile structures, customer details, and raw onboarding records for security.

### Google Location APIs
* **Google Places Autocomplete**: `maps.googleapis.com/maps/api/place/autocomplete/json`
  *Purpose*: Dynamically fetches dropdown suggestions as the user types their home address.
* **Google Maps Static API**: `maps.googleapis.com/maps/api/staticmap`
  *Purpose*: Generates static map snippets for fast thumbnail rendering in receipt and card structures.
