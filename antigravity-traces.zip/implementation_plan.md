# USTAAD App — Implementation Plan

## Goal
Build USTAAD: an Agentic AI-powered platform that connects customers with verified blue-collar service workers (plumbers, electricians, AC technicians, cleaners) in Pakistan's informal economy. The system must support three user roles (Customer, Worker, Admin) and be deployable as a Flutter web + Android app.

---

## Phase 1: Architecture & Foundation

### Design Decisions
- **Flutter** chosen as the core framework for cross-platform (Web + Android) from a single codebase.
- **Firebase Auth** for identity (Email/Password) — one account per role.
- **Firestore** for customer user profile data (name, email, address, city) and initial worker registration metadata.
- **Custom JSONBin cloud storage** (via Vercel-hosted REST proxy) for worker technician records, booking data, and complaints — chosen because it requires no backend server and supports direct REST PUT/GET.
- **PlatformStorage** (SharedPreferences wrapper) for offline caching across Web and Android.
- **go_router** for declarative routing, enabling deep linking and role-based navigation.
- **Google Maps SDK** for map display (native on Android, HTML interop on Web).
- **Google Places API** for location autocomplete.

### Folder Structure Planned
```
lib/
  data/         → Repositories and database classes
  screens/
    customer/   → All customer-facing screens
    technician/ → Worker onboarding & dashboard screens
    admin/      → Admin dashboard and management screens
  theme/        → AppColors, typography
  widgets/      → Shared reusable widgets
  routing/      → go_router configuration
```

---

## Phase 2: Authentication & Role Routing

### Customer Auth
- Registration: `signup_screen.dart` → Firebase Auth createUserWithEmailAndPassword → Firestore `users` collection.
- Login: `login_screen.dart` → Firebase Auth signInWithEmailAndPassword → Firestore `users` doc fetch → route to Customer dashboard.

### Worker Auth
- Registration: Multi-step onboarding (personal info → document upload → submission).
- Documents stored in `DocumentDatabase` (JSONBin cloud).
- Login: `tech_login_screen.dart` → Firebase Auth → fetch from `DocumentDatabase.onboardedTechnicians` → status check (approved/pending/rejected).
- **Critical Bug Fixed**: Worker login was previously reading from Firestore `workers` collection (wrong store). Fixed to read from JSONBin via `DocumentDatabase`.

### Admin Auth
- Hardcoded credentials check → route to Admin dashboard.

---

## Phase 3: Customer Journey

### Screens Implemented
1. `welcome_screen.dart` — App landing with role selection
2. `login_screen.dart` — Customer login with Firebase
3. `signup_screen.dart` — Registration with Firestore write
4. `home_screen.dart` — Service category grid + quick booking
5. `quick_service_form_screen.dart` — Structured form for service request
6. `ai_processing_screen.dart` — Agentic reasoning animation (7-step pipeline: Planning → Decision → Action → Follow-up)
7. `provider_discovery_screen.dart` — AI-ranked provider list filtered by city
8. `provider_details_screen.dart` — Worker profile, ratings, contact
9. `booking_confirmation_screen.dart` — Final booking summary with ID generation
10. `my_bookings_screen.dart` — Full booking history with status management
11. `follow_up_screen.dart` — Post-service: rate, review, raise complaint
12. `profile_screen.dart` — Customer profile management

### AI Processing Pipeline (Simulated)
The `AiProcessingScreen` simulates a 7-step agentic reasoning loop:
1. Parsing request intent
2. Analyzing service category
3. Location extraction and city isolation
4. Schedule and timing parsing
5. Cross-referencing work specifications
6. Querying local technician registry
7. AI matching optimization and ranking

---

## Phase 4: Worker Journey

### Screens Implemented
1. `tech_login_screen.dart` — Worker login with approval status gating
2. `tech_onboarding_screen.dart` — Multi-step registration form
3. `tech_documents_screen.dart` — CNIC + professional document upload → Firestore write
4. `tech_dashboard_screen.dart` — Active jobs, earnings, status toggle
5. `tech_profile_screen.dart` — Worker profile view

### Approval Flow
- Worker registers → data saved to JSONBin via `DocumentDatabase.addTechnician()`.
- Worker status set to `"pending"`.
- Admin reviews and approves → status updated to `"approved"` in JSONBin.
- Worker can login only when status is `"approved"`.

---

## Phase 5: Admin Dashboard

### Features Implemented
- Worker application list with CNIC photo display
- Approve/Reject with single tap → updates JSONBin `status` field
- Complaint management: view, resolve, add resolution notes
- Platform metrics overview

---

## Phase 6: Data Sync Architecture

### BookingsRepository
- Local cache: `SharedPreferences` key `ustaad_bookings_v2`
- Cloud sync: `https://jsonbin-zeta.vercel.app/api/bins/L5f2Y_PZP-`
- Pattern: `syncFromCloud()` on app init, `syncToCloud()` after every mutation

### DocumentDatabase (Technicians)
- Local cache: `SharedPreferences` key `ustaad_document_database_v1`
- Cloud sync: `https://jsonbin-zeta.vercel.app/api/bins/[TECH_BIN_ID]`
- Same sync pattern as BookingsRepository

### UserDatabase (Customers)
- Local cache: `SharedPreferences` key `ustaad_registered_users_v1`
- Cloud sync: `https://jsonbin-zeta.vercel.app/api/bins/VRHuwcv2Jv`

---

## Phase 7: Maps Integration

### Android
- `google_maps_flutter` SDK with `GoogleMap` widget
- Static map tile fetching for location thumbnails via Maps Static API key `AIzaSyCfyfXA-jSL2Gwc9p3lML2V6z-AwKW0m0w`

### Web
- HTML interop via `universal_html` + `js` packages
- Raw `google.maps.Map` JavaScript object injected into a `<div>` container
- `google_places_autocomplete.dart` widget for address input with Places API suggestions

---

## Phase 8: Deployment

### Web
- `flutter build web --release` generates `build/web/`
- Deployed to Vercel via GitHub integration (auto-deploys on push to `main`)

### Android
- `flutter build apk --release` generates installable APK

---

## Verification Plan
- Manual end-to-end test: Customer registers → books service → admin sees booking → worker accepts
- Worker approval flow: Worker registers → admin approves → worker logs in successfully
- Cross-device sync: Book on web → verify appears on Android (via cloud sync)
